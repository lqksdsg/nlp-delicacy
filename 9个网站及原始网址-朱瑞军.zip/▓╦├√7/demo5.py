# coding=utf-8
import bs4
import chardet

import requests
import sys
import codecs

import time
reload(sys)
result=[]
sys.setdefaultencoding('utf-8')
sys.setrecursionlimit(10000)
headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13'}
list=[]
r=open('cx.txt')
for l in r.readlines():
   # lines=l.split("\t")
  #  print lines[0]+"\t"+lines[1]
    list.append(l)
r.close()
count=0
def pagefun(a):

    list1=a.split("\t")
    r = requests.get(list1[0], headers=headers)
    soup = bs4.BeautifulSoup(r.content, "html.parser")
    for d in soup.find_all('a'):
        if d.get('class')!=None:
            if"link_hidden" in d.get("class"):
              print d.text.strip()
              #print d.text+"\t"+list1[1]
           #print d.get('alt')+"\t"+list1[1]
              result.append(d.text.strip()+"\t"+list1[1])

    for p in soup.find_all('a'):
          # print p
           if p.get('class')!=None:
              if 'page_next' in p.get('class'):
                  b=p.get('href')+"\t"+list1[1]
                  print b
                  if b in a:
                      break
                  pagefun(b)


#for p in list:
i=20
#print list[i]
pagefun(list[i])
f = codecs.open(str(i) +'.txt', 'w')
for i in result:
     print i
     f.write(i+"\n")

f.close()

