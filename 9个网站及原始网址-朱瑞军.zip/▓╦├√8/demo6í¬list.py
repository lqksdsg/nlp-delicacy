# coding=utf-8
import bs4
import chardet

import requests
import sys
import codecs

import time
reload(sys)
result=[]
#sys.setdefaultencoding('utf-8')
headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13'}
r = requests.get("http://www.ttmeishi.com/CaiXi/zhonghua/", headers=headers)
p=r.content.decode('GB2312').encode('utf-8')
soup = bs4.BeautifulSoup(p, "html.parser")
for d in soup.find_all('a'):
    print "http://www.ttmeishi.com"+d.get('href')+"\t"+d.text
    #if d.get('href')!=None:
    #print "http://www.sbar.com.cn"+d.get('href')+"\t"+d.text



