# coding=utf-8
import bs4
import chardet

import requests
import sys
import codecs

import time
reload(sys)
result=[]
sys.setdefaultencoding('utf-8')
sys.setrecursionlimit(10000)
headers = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.2) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.27 Safari/525.13'}
list=[]
r=open('cx.txt')
for l in r.readlines():
   # lines=l.split("\t")
  #  print lines[0]+"\t"+lines[1]
    list.append(l)
r.close()
count=0
def pagefun(a):

    list1=a.split("\t")
    r = requests.get(list1[0], headers=headers)
    #x = r.content.decode('GB2312').encode('utf-8')
    soup = bs4.BeautifulSoup(r.content, "html.parser")
   # print r.content
    for d in soup.find_all('img'):

        if d.get('height')!=None:
            if  '194' in d.get('height'):
              #print d.text+"\t"+list1[1]
               print d.get('alt')+"\t"+list1[1]
               result.append(d.get('alt')+"\t"+list1[1])

    for p in soup.find_all('a'):
        if '下一页' in p.text:
             b=p.get('href')+"\t"+list1[1]
             print b
    #               if b in a:
    #                   break
             pagefun(b)




#for p in list:
i=20
#print list[i]
#url=list[i].split("\t")[0]
pagefun(list[i])
f = codecs.open(str(i) +'.txt', 'w')
for i in result:
     print i
     f.write(i+"\n")

f.close()

